// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", function(e){
        e.preventDefault();

        document.querySelector(this.getAttribute("href")).scrollIntoView({
            behavior:"smooth"
        });
    });
});

// Typing effect
const text = "Web Developer • System Analyst • Hair Entrepreneur";
let i = 0;

const typing = document.querySelector(".hero-text h3");
typing.innerHTML = "";

function typeWriter(){

    if(i < text.length){
        typing.innerHTML += text.charAt(i);
        i++;
        setTimeout(typeWriter,70);
    }

}

typeWriter();

// Reveal animation
const observer = new IntersectionObserver((entries)=>{

entries.forEach(entry=>{

if(entry.isIntersecting){
entry.target.style.opacity="1";
entry.target.style.transform="translateY(0)";
}

});

});

document.querySelectorAll("section").forEach(section=>{

section.style.opacity="0";
section.style.transform="translateY(50px)";
section.style.transition="1s";

observer.observe(section);

});

// Back To Top Button
const button=document.createElement("button");

button.innerHTML="⬆";

button.style.position="fixed";
button.style.bottom="20px";
button.style.right="20px";
button.style.padding="15px";
button.style.border="none";
button.style.borderRadius="50%";
button.style.background="#f59e0b";
button.style.color="black";
button.style.fontSize="18px";
button.style.cursor="pointer";
button.style.display="none";

document.body.appendChild(button);

window.addEventListener("scroll",()=>{

if(window.scrollY>300){

button.style.display="block";

}else{

button.style.display="none";

}

});

button.onclick=()=>{

window.scrollTo({

top:0,

behavior:"smooth"

});

};